public class PracExamException extends Exception
{
	public PracExamException(String errorMessage)
	{
		super(errorMessage);
	}
}