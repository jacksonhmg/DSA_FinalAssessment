/**
 * DSA Final Assessment Question 3 - Q3TreeTest.java
 *
 * Name : 
 * ID   :
 *
 **/
public class Q3TreeTest
{
	public static void main(String args[])
	{
		System.out.println("\n##### Question 3: Testing Trees #####\n");
        	Q3BSTree t = new Q3BSTree();
		
		// put your code here
			
		System.out.println("\n##### Tests Complete #####\n");

	}
	
}
